function myFunction() {
    document.getElementById("demo").innerHTML.style.fontSize = "35px";
    }
    function myFunction1() {
        document.getElementById("demo").innerHTML = "<img src='image/2.jpg'>";
        }
function alert('아닌뒈요. 뚱인뒈엽'){
    window.alert('아닌뒈요. 뚱인뒈엽');
}